"""Build the judge-facing BCP-1 PDF from report/REPORT.md."""

from __future__ import annotations

import argparse
import html
import re
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    Preformatted,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


def inline_markup(text: str) -> str:
    escaped = html.escape(text)
    escaped = re.sub(r"`([^`]+)`", r'<font name="Courier">\1</font>', escaped)
    escaped = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", escaped)
    return escaped


def footer(canvas, document) -> None:
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#555555"))
    canvas.drawString(0.6 * inch, 0.36 * inch, "Project Ballistic — BCP-1")
    canvas.drawRightString(
        letter[0] - 0.6 * inch,
        0.36 * inch,
        f"Page {document.page}",
    )
    canvas.restoreState()


def _is_separator_row(cells: list[str]) -> bool:
    return all(re.fullmatch(r":?-{3,}:?", cell.strip()) for cell in cells)


def markdown_table(lines: list[str], width: float, styles) -> Table:
    rows: list[list[Paragraph]] = []
    for line in lines:
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if _is_separator_row(cells):
            continue
        rows.append(
            [Paragraph(inline_markup(cell), styles["TableCell"]) for cell in cells]
        )
    columns = len(rows[0])
    if columns == 4:
        widths = [width * 0.25, width * 0.39, width * 0.18, width * 0.18]
    else:
        widths = [width / columns] * columns
    table = Table(rows, colWidths=widths, repeatRows=1, hAlign="LEFT")
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8edf4")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#172033")),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#aab2bf")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [
                    colors.white,
                    colors.HexColor("#f7f8fa"),
                ]),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    return table


def build_story(source: str, content_width: float):
    base = getSampleStyleSheet()
    styles = {
        "Title": ParagraphStyle(
            "Title",
            parent=base["Title"],
            fontName="Helvetica-Bold",
            fontSize=20,
            leading=23,
            alignment=TA_CENTER,
            spaceAfter=12,
            textColor=colors.HexColor("#172033"),
        ),
        "H2": ParagraphStyle(
            "H2",
            parent=base["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=13,
            leading=15,
            spaceBefore=8,
            spaceAfter=4,
            keepWithNext=True,
            textColor=colors.HexColor("#172033"),
        ),
        "H3": ParagraphStyle(
            "H3",
            parent=base["Heading3"],
            fontName="Helvetica-Bold",
            fontSize=10.5,
            leading=12,
            spaceBefore=6,
            spaceAfter=3,
            keepWithNext=True,
        ),
        "Body": ParagraphStyle(
            "Body",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=9,
            leading=11.2,
            spaceAfter=4,
        ),
        "Meta": ParagraphStyle(
            "Meta",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=9,
            leading=11,
            alignment=TA_CENTER,
            spaceAfter=12,
            textColor=colors.HexColor("#444444"),
        ),
        "Quote": ParagraphStyle(
            "Quote",
            parent=base["BodyText"],
            fontName="Helvetica-Oblique",
            fontSize=9,
            leading=11.2,
            leftIndent=18,
            rightIndent=18,
            borderColor=colors.HexColor("#7b8798"),
            borderWidth=0,
            borderLeftWidth=2,
            borderPadding=7,
            spaceAfter=6,
        ),
        "Bullet": ParagraphStyle(
            "Bullet",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=8.8,
            leading=10.8,
            leftIndent=12,
            firstLineIndent=-9,
            spaceAfter=2,
        ),
        "Code": ParagraphStyle(
            "Code",
            parent=base["Code"],
            fontName="Courier",
            fontSize=7.5,
            leading=9,
            leftIndent=8,
            spaceAfter=5,
            backColor=colors.HexColor("#f2f3f5"),
        ),
        "TableCell": ParagraphStyle(
            "TableCell",
            parent=base["BodyText"],
            fontName="Helvetica",
            fontSize=7.7,
            leading=9.2,
        ),
    }

    story = []
    lines = source.splitlines()
    paragraph: list[str] = []
    code: list[str] = []
    in_code = False
    first_plain_line = True

    def flush_paragraph() -> None:
        nonlocal paragraph, first_plain_line
        if not paragraph:
            return
        text = " ".join(part.strip() for part in paragraph)
        style = styles["Meta"] if first_plain_line else styles["Body"]
        story.append(Paragraph(inline_markup(text), style))
        first_plain_line = False
        paragraph = []

    index = 0
    while index < len(lines):
        line = lines[index]
        stripped = line.strip()
        if stripped.startswith("```"):
            flush_paragraph()
            if in_code:
                story.append(Preformatted("\n".join(code), styles["Code"]))
                code = []
                in_code = False
            else:
                in_code = True
            index += 1
            continue
        if in_code:
            code.append(line)
            index += 1
            continue
        if stripped == "<!-- PAGEBREAK -->":
            flush_paragraph()
            story.append(PageBreak())
            index += 1
            continue
        if stripped.startswith("|"):
            flush_paragraph()
            table_lines = []
            while index < len(lines) and lines[index].strip().startswith("|"):
                table_lines.append(lines[index])
                index += 1
            story.append(markdown_table(table_lines, content_width, styles))
            story.append(Spacer(1, 6))
            continue
        if not stripped:
            flush_paragraph()
            index += 1
            continue
        if stripped.startswith("# "):
            flush_paragraph()
            story.append(Paragraph(inline_markup(stripped[2:]), styles["Title"]))
            first_plain_line = True
        elif stripped.startswith("## "):
            flush_paragraph()
            story.append(Paragraph(inline_markup(stripped[3:]), styles["H2"]))
            first_plain_line = False
        elif stripped.startswith("### "):
            flush_paragraph()
            story.append(Paragraph(inline_markup(stripped[4:]), styles["H3"]))
            first_plain_line = False
        elif stripped.startswith("> "):
            flush_paragraph()
            story.append(Paragraph(inline_markup(stripped[2:]), styles["Quote"]))
            first_plain_line = False
        elif re.match(r"^[-*]\s+", stripped):
            flush_paragraph()
            story.append(
                Paragraph(
                    "• " + inline_markup(re.sub(r"^[-*]\s+", "", stripped)),
                    styles["Bullet"],
                )
            )
            first_plain_line = False
        elif re.match(r"^\d+\.\s+", stripped):
            flush_paragraph()
            match = re.match(r"^(\d+)\.\s+(.*)", stripped)
            assert match is not None
            story.append(
                Paragraph(
                    f"{match.group(1)}. {inline_markup(match.group(2))}",
                    styles["Bullet"],
                )
            )
            first_plain_line = False
        else:
            paragraph.append(stripped)
        index += 1
    flush_paragraph()
    return story


def build_pdf(source_path: Path, output_path: Path) -> int:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    document = SimpleDocTemplate(
        str(output_path),
        pagesize=letter,
        rightMargin=0.58 * inch,
        leftMargin=0.58 * inch,
        topMargin=0.52 * inch,
        bottomMargin=0.55 * inch,
        title="BCP-1: Proof-Carrying Containment",
        author="Project Ballistic",
        subject="Apart Research AI Incident Response Sprint — Track 1",
    )
    source = source_path.read_text(encoding="utf-8")
    story = build_story(source, document.width)
    document.build(story, onFirstPage=footer, onLaterPages=footer)
    pdf = output_path.read_bytes()
    return len(re.findall(rb"/Type\s*/Page(?!s)", pdf))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--source",
        type=Path,
        default=Path("report/REPORT.md"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("submission/BCP-1-Report.pdf"),
    )
    args = parser.parse_args()
    pages = build_pdf(args.source, args.output)
    print(f"built {args.output} ({pages} pages)")
    if not 4 <= pages <= 8:
        print("warning: report is outside the sprint's 4–8 page target")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

