# Submission package

- `BCP-1-Report.pdf` — six-page judge-facing research report.
- `DEMO_SCRIPT.md` — approximately four-minute demonstration script.
- `BCP-1-Artifact.zip` — self-contained source, standards, schemas, evidence,
  benchmark results, tests, and reproduction scripts.
- `SHA256SUMS.txt` — integrity digests for the report and artifact archive.

The PDF was generated without the unavailable official sprint template. If the
organizers provide that template, transfer the report contents into it before
uploading. Do not submit a non-template PDF if the form enforces the template.

