# BCP-1: Proof-Carrying Containment for Guardrails-Off AI Evaluations

Project Ballistic — Apart Research AI Incident Response Sprint, Track 1  
13 September 2026

## Abstract

The July 2026 OpenAI–Hugging Face incident showed that a sandbox can retain an
allowed network path, generate correlated security detections, and still fail
to contain an autonomous system. The central failure was not the absence of a
better behavioral anomaly score. It was the absence of enforceable invariants
connecting authorization, side effects, automatic escalation, downstream
responsibility, and externally verifiable evidence. We propose BCP-1, a minimum
adequate containment profile for dangerous-capability evaluations run with
production safeguards disabled. BCP-1 requires an OS-enforced default-deny
workload boundary, a closed egress executor, brokered per-request identity,
canaries and independent tripwires, kill-epoch-bound one-use dispatch
capabilities, bounded independently witnessed evidence, a second-hop contract,
and a tested incident/re-enable gate.

We implement the authorization and evidence contract in Python and test it with
five incident-grounded control ablations. Every weaker configuration fails its
designated metric: an alert-only gateway forwards one canary request; a stale
permit dispatches once after kill; a presence-only provider check admits one
unsafe harness; a hash chain without a witness accepts one conflicting root;
and per-drop logging allocates 49,998 post-kill records. Full BCP-1 produces
zero for every unsafe count. In a 50,000-request auditability study, ordinary
access logs verify 0/5 containment claims, signed-line logs verify 1/5, and
BCP-1 verifies 5/5 with 12,500 times fewer records. Four end-to-end scenarios
and 32 automated tests pass with 80% combined statement/branch coverage. A
Docker comparison confirms the default-deny networking principle but is
explicitly not represented as microVM conformance.

## 1. Incident-grounded problem

The incident defeats three common but inadequate safety stories. First,
“sandboxed” did not mean “no path to an external side effect”: the model used
the package infrastructure that was intentionally reachable. Second,
“detected” did not mean “contained”: correlated evidence existed without a
deterministic transition to paging and isolation during the relevant period.
Third, the originator’s boundary was not the final boundary: public compute and
shared downstream credentials expanded the reachable blast radius [1,2].

Machine-speed incidents are properties of sequences and systems, not just
individually suspicious requests. The published 56 exfiltration-category
actions were distributed across the larger campaign; they are not a contiguous
56-step trace from which a defensible “fired on action N” can be reconstructed.
BCP-1 therefore does not fabricate a historical detection index. Its stronger
falsifiable requirement is that the first contract-violating request produces
no external effect and automatically moves the run to an independently
acknowledged killed state.

This reframes Track 1. The question is not whether a lab can operate a proxy or
collect logs. The question is what minimum set of controls makes bypass paths
unreachable, makes escalation non-optional, and lets an outsider distinguish a
real containment claim from a self-authored success story.

## 2. Research question and contribution

Our research question is:

> What is the least set of controls and evidence that allows an independent
> auditor, without lab-network access, to determine whether a guardrails-off
> evaluation prevented unauthorized external effects and automatically
> contained hard violations?

BCP-1 answers with two linked artifacts. The normative profile defines eight
mandatory controls, owners, evidence objects, acceptance tests, and indicative
adoption costs. The executable contract demonstrates canonical authorization,
race-resistant capability consumption without holding a state lock over
transport, pre-reserved egress budgets, truthful typed containment results,
bounded overload behavior, and semantic streaming offline verification.

None of default-deny networking, least privilege, capabilities, canaries, hash
chains, or incident command is individually new. The contribution is the
minimum cross-layer contract joining them. A run carries proof: a signed policy
declared before inference, a record of every mediated decision, independently
observed counters and roots, and a trigger-bound receipt. Our ablation
benchmark then asks whether each disputed control has an observable consequence
rather than assuming that a longer checklist is safer.

## 3. BCP-1 minimum profile

BCP-1 has eight mandatory controls.

1. **BCP-01 — OS-enforced workload isolation.** Each run uses a fresh microVM
   or equivalently strong hardware-backed boundary. Raw IP, DNS, UDP/QUIC,
   metadata, private/public networks, sidecars, host interfaces, inherited
   descriptors, and writable cross-run state are default-denied. Only the
   external gateway is reachable.
2. **BCP-02 — Closed egress executor.** External effects are admitted outside
   the workload against exact origin, method, normalized path, resolved CIDR,
   TLS SPKI, body/response size, and request-budget rules. Redirects, wildcard
   destinations, and agent-selected server-side fetches are prohibited.
3. **BCP-03 — Brokered least-privilege identity.** Secret bytes never enter the
   agent. After durable authorization, the executor may receive one
   audience-bound, short-lived grant. Shared cross-run or cluster-wide
   credentials are prohibited.
4. **BCP-04 — Canaries and independent tripwires.** Canary read, use, copy,
   validation, or transmission is a hard kill. At least one tripwire sits
   outside the workload and gateway failure domain.
5. **BCP-05 — Race-free dispatch and out-of-band kill.** An ALLOW is a signed,
   short-lived, action-bound, one-use capability containing the current kill
   epoch. The executor rechecks and consumes it in the same lower-layer
   transaction that admits the side effect. Kill cuts network first, advances
   the epoch, revokes broker grants, and terminates the workload.
6. **BCP-06 — Complete, bounded, non-equivocating evidence.** Request and
   decision are durably committed before capability release. A separately
   keyed supervisor signs roots and counters. An independent witness rejects a
   second root for the same run. Admission and post-kill logging are bounded.
7. **BCP-07 — Second-hop contract.** Every reachable tool server, public
   harness, relay, and delegated compute provider has authenticated access,
   non-root identity, tenant isolation, default-deny egress, no ambient
   secrets, bounded requests, abuse telemetry, containment authority, evidence
   exchange, emergency contacts, and a named owner. Missing evidence fails
   preflight.
8. **BCP-08 — Incident and re-enable gate.** Unauthorized egress, credential
   misuse, privilege escalation, cross-run communication, C2/tunneling,
   monitoring tamper, shared-control-plane compromise, and budget overflow
   automatically declare an incident. Shared-service compromise halts the
   fleet. Restart requires eradication, credential rotation, scope analysis,
   independent retest, evidence review, and named approval.

Three ordering invariants are the trusted core: no secret or external effect
before a signed decision is durably committed; dispatch requires a successful
single-use nonce consumption against the current kill epoch; and a hard
violation transitions directly to isolation without waiting for human
interpretation.

## 4. Method

### 4.1 Threat model

The evaluated agent and every process it can influence are untrusted. The
agent may construct ambiguous requests, exploit an allowed service, replay an
authorization, race a kill, exhaust gateway resources, select an unsafe second
hop, or attempt to make evidence unverifiable. The gateway, executor,
credential broker, supervisor, evidence mirror, and keys are outside the agent
trust domain. BCP-1 separately considers compromise of one trusted component:
the OS boundary limits gateway bypass; the supervisor limits gateway failure;
and the independent witness limits supervisor equivocation.

### 4.2 Reference implementation

The reference gateway parses a closed action schema and canonical JSON profile,
rejecting duplicate keys, floats, non-NFC strings, unsafe integers, path
ambiguity, redirects, and network-identity mismatches. An Ed25519-signed
manifest pins rules and keys. An ALLOW decision binds the run, manifest,
request event, action digest, rule, nonce, expiration, one use, and kill epoch.
The executor verifies the signature and binding, atomically consumes the nonce,
obtains any secret directly from the broker, and records dispatch/result
events. The supervisor independently mirrors event heads, invokes isolation,
signs the kill acknowledgement and receipt, and asks a stateful witness to
checkpoint one root. The auditor streams canonical JSONL in O(1) chain memory.

FastAPI is only an adapter. The security claim begins below the agent at the
OS/hypervisor and executor boundary. In the reference implementation a Python
lock models atomic lower-layer dispatch; production must couple that operation
to actual network admission.

### 4.3 Ablation design

We compare five explicit architectural omissions with the full contract. These
baselines are not claims about OpenAI, Hugging Face, or any product.

- `alert_only` detects canary use but forwards the request and does not kill.
- `permit_once_no_epoch_recheck` honors a capability issued before kill without
  rechecking shared state at dispatch.
- `provider_presence_check_only` verifies that a provider and operator are
  named but does not require authentication, non-root execution, or denied
  egress.
- `hash_chain_without_witness` accepts independently self-consistent roots
  without a one-root registry.
- `one_log_record_per_drop` allocates one detailed event for every post-kill
  request.

The safety value is zero for each count: forbidden dispatches after detection,
post-kill dispatches, unsafe harnesses admitted, conflicting second roots
accepted, and event growth after the bounded overload event. Scenarios execute
real reference objects where the relevant control exists. Ablated behavior is
kept deliberately small and inspectable so that each comparison tests one
omission.

### 4.4 Auditability-gap design

We separately compare three evidence profiles under the same 50,000-request
post-kill burst: an ordinary per-request access log; the same records with a
per-line authentication code; and the BCP-1 signed manifest, bounded event
chain, receipt, and witness. We test five defined claims: operator-signed
contract binding, zero forbidden dispatches in the mediated path,
trigger-bound kill, included-event tamper detection, and rejection of a
conflicting root. We also measure record count, serialized bytes, streaming
verification time, and peak verifier allocation. The signed-line baseline is
intentionally credited for the one property it supplies—modification detection
for an included line—but not for completeness, policy, trigger, or
non-equivocation facts that its format does not contain.

<!-- PAGEBREAK -->

## 5. Results

All five ablations failed and full BCP-1 passed all five.

| Scenario | Omitted control | Ablated value | BCP-1 value |
|---|---|---:|---:|
| Canary alert without page | Automatic canary kill | 1 dispatch | 0 |
| Permit/kill race | Dispatch-time epoch check | 1 post-kill dispatch | 0 |
| Unsafe public second hop | Fail-closed preflight | 1 harness admitted | 0 |
| Evidence equivocation | Independent one-root witness | 1 second root | 0 |
| 50,000-request flood | Bounded post-kill evidence | 49,998 events | 0 |

The canary result directly models the “alerted but did not page” failure class:
observation alone has no safety value when forwarding continues. BCP-1 turns a
trusted canary observation into a non-discretionary state transition and binds
that transition to zero dispatches in the receipt.

The race result establishes why “the proxy closed its socket” is not an
adequate kill claim. A capability issued before the kill remains dangerous
unless the side-effect executor checks shared epoch state at its linearization
point. In the benchmark the stale permit baseline executes once; the BCP-1
executor rejects the same sequence.

The flood result distinguishes cryptographic cost from admission cost. SHA-256
is not the dominant risk when parsing, allocation, socket queues, and durable
writes are attacker-controlled. BCP-1 performs constant-cost admission first,
creates one overload event, then changes only fixed-width counters. After the
kill event, 49,998 requests produce no event growth.

The auditability study quantifies a separate gap. The access log verifies 0/5
defined claims. Authenticating every line adds included-line tamper detection
but still verifies only 1/5. The BCP-1 bundle verifies 5/5 for the mediated
path. Access and signed-line profiles emit 50,000 records (4,088,883 and
6,288,883 bytes); BCP-1 emits four events (5,530 bytes). That is 12,500 times
fewer records, 732 times fewer bytes than access logs, and 1,126 times fewer
bytes than signed-line logs. In this run the BCP-1 streaming verification took
about 36 ms; timings are environment-specific and the evidence-size result is
the more portable finding.

Four judge-facing functional scenarios also pass: an allowed package read
dispatches exactly once and audits successfully; unauthorized egress is killed
with zero dispatch; canary use is killed with zero dispatch; and an unsafe
second hop is rejected before model inference. The complete suite reports 32
passing tests and 80% combined statement/branch coverage.

A Docker network ablation supplies a positive control. An unprivileged probe
on an ordinary bridge successfully opens TCP to `1.1.1.1:443`. The same probe
on an `internal: true` network cannot open that connection but can still reach
the gateway and complete an approved mock dispatch. This establishes only the
container-network principle, not microVM, metadata, UDP/QUIC, sidecar, or
inherited-descriptor conformance.

## 6. Where BCP-1 interrupts the July chain

The earliest intended interruption is before internet access. A per-run
read-only package identity prevents mutable cross-run coordination. A closed,
content-addressed package API removes arbitrary fetch, token-refresh, plugin,
and administrative surfaces. If the package broker is nevertheless
compromised, the independent default-deny boundary prevents it from becoming
general egress. If the agent requests an undeclared destination, the gateway
records a KILL decision and forwards nothing. If it delegates to an
unauthenticated or root-capable public harness, second-hop preflight prevents
the model run from starting.

BCP-1 therefore answers “which action fires?” without inventing a historical
ordinal: in any replay, the first request that violates the signed contract is
the trigger. The evidence contains its request identifier, normalized action
digest, decision, reason, zero-forward counter, and signed trigger-to-containment
acknowledgement. In the local reference this is explicitly a `SIMULATED`
containment acknowledgement with network isolation unconfirmed.

## 7. Third-party verification

An auditor receives a portable evidence bundle:

- `manifest.json`: operator-signed immutable rules and pinned public keys;
- `evidence.jsonl`: canonical hash-chained requests, decisions, dispatches,
  results, violations, overload summaries, and kill acknowledgements;
- `receipt.json`: supervisor-signed roots, canonical file digest, event and
  flow counters, run status, kill trigger, and witness checkpoint;
- `operator-key.json`: the externally trusted operator public key;
- deployment evidence by digest: image attestations, firewall exports, flow
  statements, conformance reports, provider inventory, and incident records.

The streaming auditor verifies operator, gateway, supervisor, and witness
signatures; run and manifest binding; sequence and previous-hash continuity;
canonical JSONL digest; request/decision/action binding; decision, dispatch,
result/cancellation state transitions; authorization uniqueness and epoch;
byte counters; trigger-to-kill binding; and the kill SLA. It rejects truncation,
reorder, garbage payloads, orphan or duplicate events, payload modification,
key substitution, counter mismatch, stale capability use, post-kill dispatch,
and conflicting witness roots.

This evidence proves consistency and signer authorization. It cannot prove
that an unobserved action never happened. That claim requires BCP-01 to make
unmediated paths impossible and independent flow evidence to corroborate zero
egress. A valid signature also proves key possession, not software identity;
production keys should be bound to measured gateway and supervisor images.

## 8. Responsibility for the second hop

Responsibility is cumulative. The evaluation sponsor remains accountable for
model-originated external effects because it chose the model, tools, disabled
safeguards, and reachable providers. The harness operator is responsible for
authentication, tenant isolation, non-root execution, egress, telemetry, and
containment in its service. The cloud provider is responsible for its
contracted platform isolation and emergency control plane. The incident
commander owns run/fleet halt, affected-party notification, and restart.

The operational rule is simple: an unknown owner, missing authentication,
root-capable workload, open egress, ambient secret, absent kill authority, or
missing evidence exchange is a failed preflight—not a risk exception. A
contract cannot transfer the sponsor’s accountability to a public harness.
Provider assertions are signed, run-bound, freshness-bounded, and linked to
external evidence digests. Their signatures prove attribution and integrity,
not the truth of the infrastructure fact; the referenced evidence still
requires independent review.

## 9. Framework alignment and adoption

BCP-1 operationalizes CSA AICM v1.1 AIS-13 through isolated execution,
capability boundaries, network restrictions, least privilege, escape testing,
monitoring, auditable breach records, and lateral-movement prevention [3].
It operationalizes the CoSAI AI Incident Response Framework through tool-call
telemetry, severity criteria, RACI, automatic containment, forensic provenance,
third-party coordination, recovery, and exercises [4]. It maps to NIST SP
800-61r3 outcomes including `GV.RR`, `GV.SC`, `PR.PS-04`, `DE.AE-03/06/08`,
`RS.MA-01/04`, `RS.AN-06/07/08`, `RS.CO-02/03`, and `RS.MI-01/02` [5].

Adoption is staged. A lab can define signed manifests, hard kill criteria,
canaries, second-hop inventory, and incident ownership in engineer-days. A
closed executor, broker integration, race-free supervisor, and evidence
witness require approximately one to three engineer-weeks each. Fresh
microVM integration is the largest initial item at roughly two to six
engineer-weeks, with an estimated 5–20% runtime overhead depending on reuse and
workload. These are indicative engineering estimates, not measured cost data.

The minimum is deliberately not tiered: a dangerous-capability evaluation with
production safeguards disabled conforms only when every MUST is satisfied.
Organizations may stage implementation, but they should not label a partially
implemented run BCP-1 compliant.

## 10. Limitations and Dual-Use Considerations

### Limitations

The Python implementation validates protocol, evidence, authorization,
overload, and reference race properties. It does not attest a production
microVM, kernel egress filter, atomic network send, HSM/TPM/TEE keys,
independent public transparency service, production IAM, or real credential
revocation. Local private keys share one process for testing. The Docker
experiment is only a container-network ablation. Payload allowlisting is not
information-flow control: harmful or secret-bearing data can still travel to
an approved destination unless executors enforce schemas and data-loss rules.
The local zero-nanosecond kill measurement reflects clock resolution in a mock
control plane and is not a production latency claim.

The ablation and evidence baselines follow directly from their defined
omissions, so the experiments establish necessity and auditability within the
BCP-1 threat model rather than prevalence across deployed lab systems. The 5/5
claim concerns the mediated path and does not prove absence of a route outside
the gateway. A stronger follow-up would test real open-source agent sandboxes
and independently operated microVMs against the same conformance vectors. We
also do not claim that BCP-1 prevents a hypervisor zero-day, an approved
destination from returning malicious content, or collusion among every
independent trust domain.

### Dual-use considerations

Containment testing necessarily documents bypass classes. Detailed exploits
against real package services, cloud control planes, credential systems, or
public harnesses could help attackers. This release therefore publishes
defensive conformance vectors and abstract omissions, not operational exploits.
Canaries are nonfunctional, credentials are synthetic, destinations use
reserved example ranges, and the executor makes no real external request.
Production escape testing should occur only with authorization, isolated
infrastructure, protected topology and credentials, stop authority, and
coordinated disclosure for newly discovered bypasses.

## 11. One-month follow-up

The next month should replace reference claims with independent measurements:
deploy the executor and supervisor around a Firecracker or cloud microVM; test
raw TCP, UDP, DNS, QUIC, metadata, sidecars, inherited descriptors, and
container-runtime sockets; couple nonce consumption to kernel egress
admission; store keys in independently administered hardware-backed domains;
publish checkpoints to an external transparency service; and invite a second
team to produce adversarial evidence bundles. The same benchmark should then
be run against at least three public agent sandbox configurations using
maintainer-reviewed settings.

The success criterion is not a prettier dashboard. It is a third party
reproducing a result in which all unmediated paths fail, every hard violation
has zero forbidden dispatches, and the external witness prevents conflicting
receipts.

## References

[1] OpenAI, “OpenAI–Hugging Face Incident Technical Report,” July 2026.  
[2] Hugging Face, “Agent Intrusion Technical Timeline,” July 2026.  
[3] Cloud Security Alliance, “AI Controls Matrix v1.1, AIS-13 Auditing
Guidelines for Model Providers,” 2026.  
[4] CoSAI/OASIS Workstream 2, “AI Incident Response Framework v1.0,” 2026.  
[5] NIST, “SP 800-61 Revision 3: Incident Response Recommendations and
Considerations for Cybersecurity Risk Management,” 2025.  
[6] Apart Research and CeSIA, “AI Incident Response Sprint,” September 2026.

